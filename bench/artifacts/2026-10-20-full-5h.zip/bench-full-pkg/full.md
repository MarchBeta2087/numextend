| suite | tier | 状态 | 耗时 s | 峰值 MB |
|---|---|---|---:|---:|
| `core.smoke` | ci | ok | 0.7 | 6 |
| `core.sweep.ci` | ci | ok | 39.8 | 6 |
| `core.math.ci` | ci | ok | 72.3 | 4 |
| `core.sweep.deep` | quick | ok | 279.0 | 148 |
| `core.math.quick` | quick | ok | 92.0 | 5 |
| `contrib.block.1e6` | quick | ok | 0.4 | 10 |
| `contrib.parallel.ntt` | quick | ok | 6.5 | 23 |
| `contrib.opencl.madddot` | quick | ok | 2.5 | 177 |
| `contrib.opencl.matmul.512` | quick | ok | 2.2 | 484 |
| `contrib.opencl.cpu.512` | quick | ok | 9.7 | 225 |
| `core.sweep.full` | full | ok | 457.1 | 293 |
| `core.math.full` | full | ok | 5627.0 | 9 |
| `core.huge.1e8` | full | ok | 130.0 | 927 |
| `contrib.block.1e8` | full | ok | 142.5 | 927 |
| `contrib.opencl.matmul.4k` | full | ok | 337.2 | 15664 |
| `contrib.ssa.1e6` | frozen | ok | 33.7 | 116 |
| `contrib.ooc.1e7` | frozen | ok | 6.8 | 131 |
| `contrib.ooc.1e8` | frozen | ok | 311.9 | 652 |
