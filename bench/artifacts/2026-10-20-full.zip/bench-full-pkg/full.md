| suite | tier | 状态 | 耗时 s | 峰值 MB |
|---|---|---|---:|---:|
| `core.sweep.full` | full | ok | 450.4 | 291 |
| `core.math.full` | full | ok | 5780.1 | 8 |
| `core.huge.1e8` | full | ok | 178.4 | 930 |
| `contrib.block.1e8` | full | ok | 217.7 | 924 |
| `contrib.opencl.matmul.4k` | full | ok | 337.4 | 15664 |
| `contrib.ssa.1e6` | frozen | ok | 33.2 | 115 |
| `contrib.ooc.1e7` | frozen | ok | 6.5 | 132 |
| `contrib.ooc.1e8` | frozen | ok | 303.9 | 652 |
